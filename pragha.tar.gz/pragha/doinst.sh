( cd usr/lib64/pragha/plugins/devices ; rm -rf libdeviceclient.so.0 )
( cd usr/lib64/pragha/plugins/devices ; ln -sf libdeviceclient.so.0.0.0 libdeviceclient.so.0 )
( cd usr/lib64/pragha/plugins/devices ; rm -rf libdeviceclient.so )
( cd usr/lib64/pragha/plugins/devices ; ln -sf libdeviceclient.so.0.0.0 libdeviceclient.so )
