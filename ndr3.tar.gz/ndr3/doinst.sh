( cd usr/bin ; ln -sf /opt/ndr3/ndr3 )
( cd usr/bin ; ln -sf /opt/ndr3/ndrlogviewer )
